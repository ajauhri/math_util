math_util 1.0
March 18, 2011

README

----------------------
This is a python module created during my Craftsmanship course at Carnegie Mellon, Spring 2011.
